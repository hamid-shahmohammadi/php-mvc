<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', '_YOUR_USER_');
  define('DB_PASS', '_YOUR_PASS_');
  define('DB_NAME', '_YOUR_DBNAME_');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/mvc/public');
  // Site Name
  define('SITENAME', '_YOUR_SITENAME_');