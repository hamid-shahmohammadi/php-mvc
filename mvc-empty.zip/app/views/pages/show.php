<?php require APPROOT . '/views/inc/header.php'; ?>
    <h1><?php var_dump($data['t']); ?></h1>
    <p>hi</p>
<?php require APPROOT . '/views/inc/footer.php'; ?>